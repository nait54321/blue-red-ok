# Ip-Attack
Auto IP or Domain Attack Tool ( #1 )

# @Name
[![20180311_081316.png](https://s13.postimg.org/h94qxghkn/20180311_081316.png)](https://postimg.org/image/s8py927zn/)

# Screenshot


[![Screenshot_2018-03-10-22-02-05.png](https://s18.postimg.org/oyveqz7t5/Screenshot_2018-03-10-22-02-05.png)](https://postimg.org/image/r3frs29fp/)

# installation

✔ apt update

✔ apt upgrade

✔ apt install git python python2

✔ cd $HOME

✔ git clone https://github.com/Bhai4You/Ip-Attack

✔ cd Ip-Attack

✔ chmod +x requirement.sh ip-attack.py

✔ bash requirement.sh

✔ python2 ip-attack.py

✔ Done...!!
